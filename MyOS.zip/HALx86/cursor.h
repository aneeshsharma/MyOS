/* Cursor operation function declarations 
   File 	-	cursor.h
   Author	-	Anish Sharma
 */

#ifndef __CURSOR_
#define __CURSOR_

void update_cursor(int col, int row);

#endif