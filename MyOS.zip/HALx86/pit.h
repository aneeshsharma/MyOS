/* Function declarations and constants for Timer (PIT) 
   File 	-	pit.h
   Author	-	Anish Sharma
 */

#ifndef __PIT_H
#define __PIT_H

#define		x86_PIT_OCW_MASK_BINCOUNT			0b00000001
#define		x86_PIT_OCW_MASK_MODE				0b00001110
#define		x86_PIT_OCW_MASK_RL					0b00110000
#define		x86_PIT_OCW_MASK_COUNTER			0b11000000

#define		x86_PIT_OCW_BINCOUNT_BINARY			0b00000000		//! Use when setting x86_PIT_OCW_MASK_BINCOUNT
#define		x86_PIT_OCW_BINCOUNT_BCD			0b00000001
#define		x86_PIT_OCW_MODE_TERMINALCOUNT		0b00000000		//! Use when setting x86_PIT_OCW_MASK_MODE
#define		x86_PIT_OCW_MODE_ONESHOT			0b00000010
#define		x86_PIT_OCW_MODE_RATEGEN			0b00000100
#define		x86_PIT_OCW_MODE_SQUAREWAVEGEN		0b00000110
#define		x86_PIT_OCW_MODE_SOFTWARETRIG		0b00001000
#define		x86_PIT_OCW_MODE_HARDWARETRIG		0b00001010
#define		x86_PIT_OCW_RL_LATCH				0b00000000	//! Use when setting x86_PIT_OCW_MASK_RL
#define		x86_PIT_OCW_RL_LSBONLY				0b00010000
#define		x86_PIT_OCW_RL_MSBONLY				0b00100000
#define		x86_PIT_OCW_RL_DATA					0b00110000
#define		x86_PIT_OCW_COUNTER_0				0b00000000	//! Use when setting x86_PIT_OCW_MASK_COUNTER
#define		x86_PIT_OCW_COUNTER_1				0b01000000
#define		x86_PIT_OCW_COUNTER_2				0b10000000

#define		x86_PIT_REG_COUNTER0				0x40
#define		x86_PIT_REG_COUNTER1				0x41
#define		x86_PIT_REG_COUNTER2				0x42
#define		x86_PIT_REG_COMMAND					0x43

#endif