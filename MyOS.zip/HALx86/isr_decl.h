/* ISR Declaration 
   File 	-	isr_decl.h
   Author	-	Anish Sharma
 */

#ifndef __ISR_DECL_h
#define __ISR_DECL_h

extern void isr0();
extern void isr1();
extern void isr3();
extern void isr4();
extern void isr5();
extern void isr11();

#endif