/* Declaration of some Miscellaneous Functions 
   File 	-	misc.h
   Author	-	Anish Sharma
 */

#ifndef __MISC_H
#define __MISC_H

void delay();

void print_help();

#endif