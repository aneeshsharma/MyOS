/* Header file defining interrupt handlers
 * File 	- irq.h
 * Author 	- Anish Sharma
 */

#include "irq.h"
#include "stdint.h"