/* Declaring some constants for specific character ASCII codes 
   File 	-	characters.h
   Author	-	Anish Sharma
 */

#ifndef __CHARACTERS_H
#define __CHARACTERS_H

#define		SL_HOZ	0xc4
#define		DL_HOZ	0xcd

#endif